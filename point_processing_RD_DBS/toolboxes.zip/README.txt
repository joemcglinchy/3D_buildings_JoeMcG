PyHull has no stable build for windows. unfortunate. There's a scipy wrapper for small parts of the QHull library:

Spatial algorithms and data structures (scipy.spatial)

Nearest-neighbor Queries
KDTree(data[, leafsize])	kd-tree for quick nearest-neighbor lookup
cKDTree	kd-tree for quick nearest-neighbor lookup
distance	
Rectangle(maxes, mins)	Hyperrectangle class.

Delaunay Triangulation, Convex Hulls and Voronoi Diagrams
Delaunay(points[, furthest_site, ...])	Delaunay tesselation in N dimensions.
ConvexHull(points[, incremental, qhull_options])	Convex hulls in N dimensions.
Voronoi(points[, furthest_site, ...])	Voronoi diagrams in N dimensions.

Plotting Helpers
delaunay_plot_2d(tri[, ax])	Plot the given Delaunay triangulation in 2-D
convex_hull_plot_2d(hull[, ax])	Plot the given convex hull diagram in 2-D
voronoi_plot_2d(vor[, ax])	Plot the given Voronoi diagram in 2-D